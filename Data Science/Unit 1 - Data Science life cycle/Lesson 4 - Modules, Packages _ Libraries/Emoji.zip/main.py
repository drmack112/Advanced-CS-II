# <-- Check out the requirement.txt file to see the libraries

# imports a SPECIFIC function from the emoji library 
from emoji import emojize 

# imports the whole emojis library
import emojis

print()
print(emojize(":thumbs_up:")) 

print()
print("There is a " + emojize(":snake:") + " in my boot!") 

print()
print(emojis.encode("This is a message with two emojis :stuck_out_tongue_winking_eye: :collision:"))